package hcl.tech;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class HclApiGatewayApplicationTests {

	@Test
	void contextLoads() {
	}

}
