package hcl.tech;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class HclUserPortfolioApplicationTests {

	@Test
	void contextLoads() {
	}

}
